
with open("7_mas.txt","r") as f:
    y=f.readline()



    
q=y.split(".")
z=y.split(" ")

print(y)
print(f"{len(q)-1}- ta gap. {len(z)}- ta so'z")