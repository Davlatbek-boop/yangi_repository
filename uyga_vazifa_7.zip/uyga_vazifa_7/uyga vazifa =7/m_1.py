import colorama
from colorama import Fore, Style

a=input(Fore.RED+"qizil: ")

b=input(Fore.YELLOW+"sariq: ")

c=input(Fore.GREEN+"yashil: ")


print(Fore.RED+a)
print(Fore.YELLOW+b)
print(Fore.GREEN+c)