import random

def randon(a,n):
    b=[]
    for i in range(n):
        a=random.randint(-50, 51)
        b.append(a)
    return b
        

n=int(input("n= "))
a=[]
q=randon(a,n)
z=""
w=""
for i in q:
    if i>0:
        z+=str(i)
        z+="  "
    else:
        w+=str(i)
        w+="  "

with open("musbat.txt", "w") as f:
    f.write(z)
with open("manfiy.txt", "w") as f:
    f.write(w)