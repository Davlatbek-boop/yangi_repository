import random

def randon(a):
    b=[]
    for i in range(100):
        a=random.randint(100, 1000)
        b.append(a)
    return b
        


a=[]
q=randon(a)
tanlash=random.sample(q,1)
print(f"tanlangan son>>> {tanlash}")
print("Tasodifiy sonlarning juftlari:")
for i in q:
    if i==tanlash:
        break
    if i%2==0:
        print(i, end="  ")

