
# def sezar(a):
#     for i in range(len(a)):
#         if a[i]=='0':
#             a[i]="7"
#         elif a[i]=='1':
#             a[i]='8'
#         elif a[i]=='2':
#             a[i]='9'
#         elif a[i]=='3':
#             a[i]='0'
#         elif a[i]=='4':
#             a[i]='1'
#         elif a[i]=='5':
#             a[i]='2'
#         elif a[i]=='6':
#             a[i]='3'
#         elif a[i]=='7':
#             a[i]='4'
#         elif a[i]=='8':
#             a[i]='5'
#         elif a[i]=='9':
#             a[i]='6'
    
    # print(''.join(a))
        

def sezar(a):
    for i in range(len(a)):
        if int(a[i])>2:
            a[i]=str(int(a[i])-3)
        else:
            a[i]=str(int(a[i])+7)
    print(''.join(a))
            




a=list(input("son kiriting>>>"))
sezar(a)