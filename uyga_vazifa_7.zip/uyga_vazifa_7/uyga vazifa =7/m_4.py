import random

def randon(a):
    b=[]
    for i in range(1000):
        a=random.randint(1, 1000000)
        b.append(a)
    return b
        
def istub(a):
    for i in range(2,a):
        if a%i==0:
            return False
    return True


a=[]
q=randon(a)
tanlash=random.sample(q,1)
print(f"tanlangan son>>> {tanlash}")
print("Tasodifiy sonlarning tublari:")
for i in q:
    if i==tanlash:
        break
    if istub(i):
        print(i, end="  ")

