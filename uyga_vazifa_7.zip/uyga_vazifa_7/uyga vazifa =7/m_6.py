

with open("mas_6.txt","r") as f:
    y=f.readline()

y=y.split(" ")


z=[]
for i in y:
    z.append(int(i))

print(z)
print(f"max= {max(z)}")


